#!/bin/bash
n=11
if[ $n -lt 10 ]
then
    echo "Small number"
else
    echo "Big number"
fi

