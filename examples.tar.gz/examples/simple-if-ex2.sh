#!/bin/bash
n="eleven"
if [ $n -lt 10 ]
then
    echo "Small number"
else
    echo "Big number"
fi

