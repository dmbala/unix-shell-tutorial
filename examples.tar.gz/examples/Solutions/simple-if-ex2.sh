#!/bin/bash
n="eleven"
if [ $n -lt 10 ]
then
    echo "Small number"
else
    echo "Big number"
fi

# input is in string. write in integer. 
